new_elearning
=============

New Elearning (LMS) dokumenary
By     : http://www.dokumenary.net
Author : Almazari <almazary@gmail.com>

Sebuah aplikasi yang dapat digunakan sebagai media untuk kegiatan belajar dan mengajar disekolah tingkat SMP/SMA/SMK sederajat atau instansi pendidikan lainnya, dan telah digunakan oleh banyak sekolah - sekolah di Indonesia sejak versi 1.0 dibagikan.

Secara umum, aplikasi ini memiliki fitur sebagai berikut:
- Pengumuman
- Pesan antar pengguna
- Pengolahan data siswa
- Pengolahan data pengajar
- Tugas (Pilihan Ganda, Essay dan Upload)
- Ujian online
- Berbagi materi
- Diskusi materi
- Jadwal matapelajaran siswa

Untuk pengguna terbagi menjadi tiga, yaitu:
- Siswa
- Pengajar
- Administrator (Pengajar yang bertindak sebagai administrator)

Lisensi:
- Gratis untuk digunakan, disalin, dimodifikasi, didistribusikan. Selengkapnya terdapat pada file license.txt

Kebutuhan:
- PHP >= 5.5
- Mysql

Versi terbaru: 2.0

<a href="http://www.dokumenary.net/demo-aplikasi-elearning/">DEMO</a> | <a href="http://dokumenary.net">PORTAL UPDATE</a> | <a href="http://www.dokumenary.net/2015/08/23/new-elearning-versi-1-0/">PANDUAN INSTALL</a>
